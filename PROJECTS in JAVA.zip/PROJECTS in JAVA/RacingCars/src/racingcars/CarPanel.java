/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package racingcars;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
/**
 *
 * @author Mohammed Eid
 */
public class CarPanel extends JPanel{
    private char forwardKey = 'w';
    private boolean reachedTarget = false;
    private Color color = Color.blue;
    private int x= 10;
    private int y= 10;

    private int panelWidth;
    private int panelHeight;

    //default Constructor
    public CarPanel(){
    }

    //overloaded Constructor
    public CarPanel(char key, Color color){
        this.forwardKey=key;
        this.color = color;
    }

    protected void paintComponent(Graphics g){
        super.paintComponent(g);

        g.setColor(Color.GREEN);
        g.fillOval(0,0,25,25);

        panelWidth= getWidth();
        panelHeight= getHeight();

        //draw a Car
        g.setColor(color);

        //polygon points
        int t_x[]= {x+10,x+20,x+30,x+40};
        int t_y[]= {y+10,y,y,y+10};

        g.fillPolygon(t_x,t_y,t_x.length);
        g.fillRect(x, y+10, 50, 10);
        g.fillArc(x+10, y+20, 10, 10, 0, 360);
        g.fillArc(x+30, y+20, 10, 10, 0, 360);
    }

    @Override
    public Dimension getPreferredSize() {
       return new Dimension(750,100);
    }

    public void moveCar(){
        if(this.x < panelWidth){
            this.x+=10;
            repaint();
        }
    }
}
