/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package racingcars;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 *
 * @author Mohammed Eid
 */
public class RacingCars extends JFrame{
    CarPanel car1;
    CarPanel car2;

    //Constructor
    public RacingCars(){
        setLayout(new GridLayout(2,1));
        car1 = new CarPanel('w',Color.RED);
        car2 = new CarPanel('k',Color.blue);

        car1.setBackground(Color.black);
        this.add(car1, BorderLayout.NORTH);
        this.add(car2, BorderLayout.SOUTH);

        this.addKeyListener(new MyKeyListener());
    }

    class MyKeyListener extends KeyAdapter{
        public void keyPressed(KeyEvent e){
            if(e.getKeyChar()=='w'){
                car1.moveCar();
            }
            if(e.getKeyChar()=='k'){
                car2.moveCar();
            }
        }
    }

    public static void main(String[] args) {
        //Create the frame on the event dispatching thread
        SwingUtilities.invokeLater(new Runnable(){

            @Override
            public void run() {
                RacingCars rc = new RacingCars();
                rc.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                rc.pack();
                rc.setVisible(true);
            }

        });
    }
}
