/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package vectorquantization;

import java.util.ArrayList;
import java.util.Vector;

/**
 *
 * @author Mohammed Eid
 */
public class VectorQuantization {
    ArrayList<Vector> vector = new ArrayList();
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
