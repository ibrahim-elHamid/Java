/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgnew.snack;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author Mohammed Eid
 */
public class NewSnack extends JFrame implements Runnable ,KeyListener{
    
    JPanel p , p1;
    JButton[] lb = new JButton[200];
    int[] lbx = new int[200];
    int[] lby = new int[200];
    int speed = 50 , food = 3, directionx = 1, directiony = 0 , boundX = 500 , boundY = 250, score = 0;
    Thread myt;
    JTextArea t;
    Random r = new Random();
    Point[] location = new Point[200];
    boolean moveRight = true , moveLeft = false , moveUP = true , moveDown = true, foodExit = false;
    public void intializeValues(){
        lbx[0] = 100;
        lby[0] = 150;
        directionx = 10;
        directiony = 0;
        moveRight = true;
        moveLeft = false;
        moveUP = true ;
        moveDown = true;
        foodExit = false;
        score = 0;
    }
     NewSnack(){
         
        super("Snack");
        setSize(500, 330);
        intializeValues();
        
        p = new JPanel();
        //JPanel p1 = new JPanel();
        create();
        p.setLayout(null);
        p.setBounds(0, 0, boundX, boundY);
        p.setBackground(Color.blue);
        getContentPane().setLayout(null);
        getContentPane().add(p);
        p1 = new JPanel();
        t = new JTextArea("Score ==>" + score);
        t.setEnabled(false);
        t.setBackground(Color.BLACK);
        
        p1.setLayout(new GridLayout(0, 1));
        p1.setBounds(0, boundY, boundX, 30);
        p1.setBackground(Color.red);
        p1.add(t);
        getContentPane().setLayout(null);
        getContentPane().add(p1);
        show();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        addKeyListener(this);
        myt = new Thread(this);
        myt.start(); // go to run() method
    }
     public void create(){
         for(int i=0;i<3;i++){
             lb[i] = new JButton("lb"+i);
             lb[i].setEnabled(false);
             p.add(lb[i]);
             lb[i].setBounds(lbx[i], lby[i], 10, 10);
             lbx[i + 1] = lbx[i] - 10;
             lby[i + 1] = lby[i];
         }
     }
     public void createFood() {
        lb[food] = new JButton();
        lb[food].setEnabled(false);
        int a = 10 + 10*r.nextInt(50);
        int b = 10 + 10*r.nextInt(20);
        p.add(lb[food]);
        lbx[food] = a;
        lby[food] = b;
        lb[food].setBounds(a, b, 10, 10);
        food++;
    }
     public void createExtraFood() {
        lb[food] = new JButton();
        lb[food].setEnabled(false);
        int a = 10 + 10*r.nextInt(50);
        int b = 10 + 10*r.nextInt(25);
        p.add(lb[food]);
        lbx[food] = a;
        lby[food] = b;
        lb[food].setBounds((10 * r.nextInt(50)), (10 * r.nextInt(25)), 25, 25);
        food++;
    }
    public void move(){
        for(int i=0;i<food;i++){
            location[i] = lb[i].getLocation();
        }
        
        lbx[0] += directionx;
        lby[0] += directiony;
        lb[0].setBounds(lbx[0], lby[0], 10, 10);
        
        for(int i=1;i<food;i++){
            lb[i].setLocation(location[i-1]);
        }
        
        if(lbx[0] == boundX)
            lbx[0] = 10;
        else if(lbx[0] == 0)
            lbx[0] = boundX - 10;
        else if(lby[0] == 0)
            lby[0] = boundY - 10;
        else if(lby[0] == boundY)
            lby[0] = 10;
        
        
        if(lbx[0] == lbx[food - 1] && lby[0] == lby[food -1]){
            foodExit = false;
            if(score % 25 == 0 && score != 0){
                t.setText("Score ==> "+(score += 10));
            }
            else{
                t.setText("Score ==> "+(score += 5));
            }
            p.remove(lb[food - 1]);
            
            for (int i = 0; i < food - 1; i++){
                p.remove(lb[i]);
            }
            for (int i = 0; i < food; i++) {
            lb[i] = new JButton("lb" + i);
            lb[i].setEnabled(false);
            p.add(lb[i]);
            lb[i].setBounds(lbx[i], lby[i], 10, 10);
            lbx[i + 1] = lbx[i] - 10;
            lby[i + 1] = lby[i];
        }
        }
        if(foodExit == false){
            if(score % 25 == 0 && score != 0){
                createExtraFood();
                //createFood();
            }
            else{
                createFood();
            }
            foodExit = true;
        }
        else if(foodExit == true){
            lb[food - 1].setBounds(lbx[food -1], lby[food - 1], 10, 10);
        }
        p.repaint();
        show();
    }
     public static void main(String[] args) {
        new NewSnack();
    }
    
    public void keyPressed(KeyEvent e) {
        
        if(moveRight == true && e.getKeyCode() == KeyEvent.VK_RIGHT){
            directionx = +10;
            directiony = 0;
            moveLeft= false;
            moveUP   = true;
            moveDown = true;
        }
        
        if(moveLeft == true && e.getKeyCode() == KeyEvent.VK_LEFT){
            directionx = -10;
            directiony = 0;
            moveRight= false;
            moveUP   = true;
            moveDown = true;
        }
        
        if(moveUP == true && e.getKeyCode() == KeyEvent.VK_UP){
            directiony = -10;
            directionx = 0;
            moveDown = false;
            moveRight = true;
            moveLeft  = true;
        }
        
        if(moveDown == true && e.getKeyCode() == KeyEvent.VK_DOWN){
            directiony = +10;
            directionx = 0;
            moveUP    = false;
            moveRight = true;
            moveLeft  = true;
        }
        if(e.getKeyCode() == KeyEvent.VK_P){
            //Pause();
        }
        
    }

    public void keyTyped(KeyEvent e) {
        
    }

    public void keyReleased(KeyEvent e) {
        
    }
    public void run() {
        for (;;){
            move();
        try {
                Thread.sleep(speed);
            } catch (InterruptedException ie){
            }
        }
    }
}
