/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc1;

/**
 *
 * @author Mohammed Eid
 */
import java.sql.*;
class Jdbc1
{
  public  static void main(String args[]) 
	{
	try
           {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");    		
  		System.out.println("Driver loaded");
 		String url="jdbc:odbc:shetty";
                Connection cn= DriverManager.getConnection(url);
                System.out.println("Connection to the database created");
		}
       catch(SQLException s)
         {
          System.out.println("sql error");
          }
        catch(Exception e)
         {
          System.out.println(" error");
          }
    }
}