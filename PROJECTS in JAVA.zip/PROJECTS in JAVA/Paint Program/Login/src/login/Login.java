/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

/**
 *
 * @author Mohammed Eid
 */
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import sun.applet.Main;


/**
 *
 * @author Mohammed Eid
 */
public class Login extends JFrame implements ActionListener {
	String Username,Password;
	Image titleImage=Toolkit.getDefaultToolkit().getImage("7.jpg");
	Font font=new Font("Times new Roman",3,25);
	Font font1=new Font("Times new Roman",1,14);
	Container con;
	JLabel title=new JLabel("MR Work Management System");
	JLabel username=new JLabel("User Name");
	JLabel pwd=new JLabel("Password");
	JTextField usernameTxt=new JTextField();
	JPasswordField pwdTxt=new JPasswordField();
	
	JButton submit=new JButton("Submit");
	JButton exit=new JButton("Exit");
	JPanel panel;
	
	
	
    public Login() {
    	 panel=new JPanel()
		    {
			Image panelImage=Toolkit.getDefaultToolkit().getImage("8.jpg");
			public void paintComponent(Graphics g)
			{
				super.paintComponent(g);
				g.drawImage(panelImage, 10,10, 350, 400,this);
			}
			
		    };
		 
			setTitle("MR System");
			setIconImage(titleImage);
			con=getContentPane();
			setLayout(null);
			setBounds(150,100,700,500);
			con.add(panel);
			panel.setLayout(null);
			panel.setBounds(20, 75, 350, 400);
			con.add(title).setFont(font);
			con.add(username).setFont(font1);
			con.add(usernameTxt).setFont(font1);
			con.add(pwd).setFont(font1);
			con.add(pwdTxt).setFont(font1);
			con.add(submit).setFont(font1);
			con.add(exit).setFont(font1);
			
			title.setBounds(150, 30, 400, 30);
			
			username.setBounds(400, 150, 100, 25);
			usernameTxt.setBounds(500, 150, 100, 25);
			
			pwd.setBounds(400, 200, 100, 25);
			pwdTxt.setBounds(500, 200, 100, 25);
			
			submit.setBounds(430, 250, 100, 25);
			exit.setBounds(570, 250, 100, 25);
		    setVisible(true);
		    
		    submit.addActionListener(this);
		    exit.addActionListener(this);
	}

    public void actionPerformed(ActionEvent event)
	{
		if(event.getActionCommand()=="Submit")
		{
			Username=usernameTxt.getText();
			Password=pwdTxt.getText();
			
			if(Username.equalsIgnoreCase("admin")&&Password.equalsIgnoreCase("admin"))
			{
				//Main.login.setText("LogOut");
				///Main.master.setEnabled(true);
				//Main.operation.setEnabled(true);
				///Main.report.setEnabled(true);
				this.hide();
				
			}
		}
		if(event.getActionCommand()=="Exit")
		{
			System.exit(0);
		}
	}

    public static void main(String[] args) {
            Login login = new Login();
            // TODO code application logic here
    }
}
