/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package paint;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

/**
 *
 * @author Mohammed Eid
 */
public class Paint {
    private JFrame f;
    private JButton chooseColor;
    public void setUP(){
        f = new JFrame();
        PaintClass p = new PaintClass();
        chooseColor = new JButton("Choose Color");
        chooseColor.setBounds(200, 5, 150, 25);
        chooseColor.setBackground(Color.red);
        f.add(chooseColor);
        p.setSize(f.getWidth(), f.getHeight());
        f.add(p);
        f.setSize(600, 500);
        f.setBackground(Color.white);
        f.setDefaultCloseOperation(EXIT_ON_CLOSE);
        f.setLocationRelativeTo(null);
        f.setTitle("ENG: Mohammed Eid ==>> Paint Program");
        f.setVisible(true);
        TheHanddler hd = new TheHanddler();
        chooseColor.addActionListener(hd);
    }
    private class TheHanddler implements ActionListener {
        
        @Override
        public void actionPerformed(ActionEvent e){
            if(e.getSource() == chooseColor){
                JColorChooser ch = new JColorChooser();
                Color c = JColorChooser.showDialog(null, "Choose your Color", Color.white);
                f.setBackground(c);
            }
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //FormClass f = new FormClass();
        Paint p = new Paint();
        p.setUP();
        // TODO code application logic here
    }
}
