import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.util.*;
class Car{
  Image img;
  int x, y;
  Dimension dim;
  Car(Image img){
    this.img=img;
  }  
  Car(Image img, int x, int y){
    this.img=img; this.x=x; this.y=y;
  }
  Car(Image img, int x, int y, Dimension dim){
    this(img, x, y);
    this.dim=dim;
  }
  void draw(Graphics g, ImageObserver observer){
    g.drawImage(img, x, y, observer);  
  }
  int getX(){ return x;}
  int getY(){ return y;}
  void setX(int x){this.x=x;}
  void setY(int y){this.y=y;}
  void setLocation(int x, int y){
    this.x=x; this.y=y;
  }
  
  int getWidth(){ return img.getWidth(null);}
  int getHeight(){ return img.getHeight(null);}
  Rectangle2D getRectangle(){
    return new Rectangle2D.Float(x, y, getWidth(), getHeight());
  }
  void move(int dx, int dy){
    x+=dx;
    y+=dy;
    if(dim!=null){
      if(x<0)x=0;
      if(x+getWidth()>dim.getWidth()) 
        x=(int)dim.getWidth()-getWidth();
    }
  }
  boolean intersects(Car car){
    return getRectangle().intersects(car.getRectangle());
  }
  boolean intersects(int x, int y){
    return getRectangle().intersects(x, y, getWidth(), getHeight());
  }
}
public class CarRace extends Applet implements KeyListener, Runnable{
  Image buff;
  Canvas screen;
  Graphics2D gs, gb;
  Car redCar;
  Car[] enemy=new Car[20];
  Button bStart;
  Thread game;
  boolean loop=true;
  Dimension dim=new Dimension(200, 300);
  int road;
  Random rnd=new Random();
  public void init(){
    prepareResource();
    setBackground(Color.blue);
    initScreen();
    add(screen);
    bStart=new Button("��ʼ��Ϸ");
    add(bStart);
    bStart.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ae){
        screen.requestFocus();
        if(!game.isAlive())
           game.start();
      }
    });
  }
  void prepareResource(){
    Image imgRed=getImage(getCodeBase(),"images/red_car.gif");
    Image imgBlue=getImage(getCodeBase(),"images/blue_car.gif");
    Image imgGreen=getImage(getCodeBase(),"images/green_car.gif");
    MediaTracker mt=new MediaTracker(this);
    try{
      mt.addImage(imgRed, 0);
      mt.addImage(imgBlue, 1);
      mt.addImage(imgGreen, 2);
      mt.waitForAll();
    }catch(Exception e){}
    buff=createImage((int)dim.getWidth(), (int)dim.getHeight());
    gb=(Graphics2D)buff.getGraphics();
    redCar=new Car(imgRed, 80,250, dim);
    
    for(int i=0;i<10;i++){
       enemy[i]=new Car(imgBlue, 0, 0);
    }
    for(int i=10;i<enemy.length;i++){
       enemy[i]=new Car(imgGreen, 0, 0);
    }
    for(int i=0;i<enemy.length;i++){
       setEnemy(i);
    }
    game=new Thread(this);
  }
  public void stop(){
    loop=false;
  }
  public void run(){
    while(loop){
       drawScreen();
       try{ Thread.sleep(50);}catch(Exception e){}
    }  
  }
  void initScreen(){
    screen=new Canvas(){
       public void paint(Graphics g){
         if(gs==null){
           gs=(Graphics2D)screen.getGraphics();
         }  
         drawScreen();
       }
    };
    screen.setSize(dim);
    screen.addKeyListener(this);
  }
  void setEnemy(int en){
    int x, y;
next:while(true){
       x=rnd.nextInt((int)dim.getWidth()-enemy[en].getWidth());
       y=-rnd.nextInt(5000)-200;
       for(int j=0;j<enemy.length;j++){
         if(j!=en && enemy[j].intersects(x, y))continue next;
       }
       enemy[en].setLocation(x, y);
       break;
    }
  }
  void check(Car en){
      if(redCar.intersects(en)){
         if(redCar.getX()>en.getX()){
           en.move(-20, 0);
           redCar.move(20, 0);
         }  
         else{
           en.move(20,0);
           redCar.move(-20, 0);
         }  
      } 
  }
  synchronized void drawScreen(){
    gb.clearRect(0, 0, (int)dim.getWidth(), (int)dim.getHeight());
    gb.setPaint(new Color(100, 100, 100));
    gb.fillRect(0, 0, (int)dim.getWidth(), (int)dim.getHeight());
    drawRoad();
    for(int i=0;i<enemy.length;i++){
       enemy[i].move(0, 15);
       enemy[i].draw(gb, screen);
       if(enemy[i].getY()>dim.getHeight())
         setEnemy(i);
       check(enemy[i]);  
    }
    redCar.draw(gb, screen);
    gs.drawImage(buff, 0,0, screen);
  }
  void drawRoad(){
    road+=80;
    gb.setPaint(Color.yellow);
    gb.fillRect((int)dim.getWidth()/2, road,10,150);
    if(road>=dim.getHeight())road=-150;
  }
  public void keyPressed(KeyEvent ke){
    if(ke.getKeyCode()==KeyEvent.VK_LEFT){
       redCar.move(-10,0);
    } 
    else if(ke.getKeyCode()==KeyEvent.VK_RIGHT){
       redCar.move(10,0);
    }    
  }
  public void keyReleased(KeyEvent ke){}
  public void keyTyped(KeyEvent ke){}
}
