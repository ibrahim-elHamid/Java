/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package newtetris;

/**
 *
 * @author Mohammed Eid
 */
public enum countriesEnum {
    Egypt ("Cairo" , "85000000" , "Pyramids" ) , 
    Yemen ("Sanna" , "25000000" , "Old sanna") , 
    Jordan("Amman" , "80000000" , "Petra")     ,
    SaudiaArabia ("Jeddah" , "100000000" , "Mecca");
    
    private final String c_capital;
    private final String c_population;
    private final String c_place;
    
    countriesEnum(String capital , String population , String place){
        c_capital = capital;
        c_population = population;
        c_place = place;
    }
    
    public String getCapital(){
        return c_capital;
    }
    
    public String getPopulation(){
        return c_population;
    }
    
    public String getPlace(){
        return c_place;
    }
    
    
}
