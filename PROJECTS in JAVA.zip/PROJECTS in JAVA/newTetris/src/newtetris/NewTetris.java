/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package newtetris;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.EnumSet;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.isDefaultLookAndFeelDecorated;
import javax.swing.JPanel;

/**
 *
 * @author Mohammed Eid
 */
public class NewTetris extends  JFrame  implements Runnable ,KeyListener {

    ArrayList<JButton> buttons = new ArrayList();
    JFrame frame;
    JPanel panel;
    int curX = 0;
    int curY = 0;
    int newX = 0;
    int newY = 0;
    

    public void drawBoard() {
        JFrame.setDefaultLookAndFeelDecorated(true);
        frame = new JFrame("Eng:Mohammed Eid ==> Tetris");
        frame.setBackground(Color.yellow);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        //frame.setLocationByPlatform(true);
        frame.setSize(1000, 640);
        frame.isPreferredSizeSet();
        frame.setLayout(null);
        
        panel = new JPanel();
        panel.setLayout(null);
        panel.setBounds(0, 100, 990, 500);
        panel.setBackground(Color.green);
        frame.add(panel);
        //JButton button = new JButton();
        /*for (int i = 0; i < 15; i++) {
            for (int j = 0; j < 10; j++) {
                JButton butt = new JButton();

                butt.setBackground(Color.yellow);
                butt.setBounds(j * 30, (i * 30 + 110), 30, 30);
                butt.setLayout(null);
                frame.add(butt);
            }
        }*/
        frame.show();
    }

    public void drawShapes() {
        //draw the square shape
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                JButton butt = new JButton();
                butt.setBackground(Color.red);
                butt.setBounds(30 * j, 30 * i, 30, 30);
                butt.setLayout(null);
                //panel.add(butt);
            }
        }
        //draw the line shape
        for (int i = 0; i < 1; i++) {
        //for (int j = 0; j < 2; j++) {
                JButton butt = new JButton();
                butt.setBackground(Color.red);
                butt.setBounds((30 * i)+500, 100, 30, 30);
                butt.setLayout(null);
                panel.add(butt);
                buttons.add(butt);
        //    }
        }
        //draw the L shape
        for (int i = 0; i < 4; i++) {
        //for (int j = 0; j < 2; j++) {
                JButton butt = new JButton();
                butt.setBackground(Color.red);
                butt.setBounds(0, 30*i, 30, 30);
                butt.setLayout(null);
                //panel.add(butt);
        //    }
        }
    }
    public void move(){
        int x = buttons.get(0).getX();
        int y = buttons.get(0).getY();
        System.out.println(buttons.size());
        System.out.println("x= "+x);
        for(;;){
            x+=1;
            if(x > 870){
                x = 100;
            }
            //y+=30;
            buttons.get(0).setBounds(x, y, 30, 30);
            panel.add(buttons.get(0));
            repaint();
        }
    }

    /**
     * @param args the command line arguments       
     */
    public static void main(String[] args) {
        
        for(countriesEnum con : EnumSet.range(countriesEnum.Egypt, countriesEnum.Yemen)){
            System.out.print(con.getCapital()+" "+con.getPopulation()+" "+con.getPlace()+" ");
        }
        NewTetris t = new NewTetris();
        t.drawBoard();
        t.drawShapes();
        t.move();
        // TODO code application logic here
    }

    @Override
    public void run() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyReleased(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
