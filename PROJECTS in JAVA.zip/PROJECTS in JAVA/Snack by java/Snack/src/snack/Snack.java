/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package snack;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Mohammed Eid
 */
public class Snack extends KeyAdapter{
    private Component component;
    private int deltaX;
    private int deltaY;
    
    public Snack(Component component, int deltaX, int deltaY){
        this.component = component;
        this.deltaX = deltaX;
        this.deltaY = deltaY;
    }
    
    public void move(int deltaX , int deltaY){
        
        int componentWidth = component.getSize().width;
        int componentHight = component.getSize().height;
        
        Dimension parentSize = component.getParent().getSize();          //////component.getParent.width;
        
        int parentWidth = parentSize.width;
        int parentHight = parentSize.height;
        
        int nextX = Math.max(component.getLocation().x + deltaX, 0);
        int nextY = Math.max(component.getLocation().y + deltaY, 0);
        
        if(nextX + componentWidth > parentWidth){
            nextX = parentWidth - componentWidth;
        }
        
        if(nextY + componentHight > parentHight){
            nextY = parentHight - componentHight;
        }
        
        component.setLocation(nextX, nextY);
    }
    
    public void keyPressed(KeyEvent e){
        if(e.getKeyCode() == KeyEvent.VK_LEFT){
            move(-deltaX, 0);
        }
        else if(e.getKeyCode() == KeyEvent.VK_RIGHT){
            move(deltaX, 0);
        }
        else if(e.getKeyCode() == KeyEvent.VK_UP){
            move(0, -deltaY);
        }
        else if(e.getKeyCode() == KeyEvent.VK_DOWN){
            move(0, deltaY);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JPanel content = new JPanel();
        content.setLayout(null);
        JLabel component = new JLabel( new colorIcon(Color.red, 40, 5));
        component.setBackground(Color.red);
        component.setSize(component.getPreferredSize());
        component.setLocation(100, 100);
        content.add(component);
        
        KeyListener KeyListener =  new Snack(component , 3, 3);   ///extends KeyAdapter
        component.addKeyListener(KeyListener);
        component.setFocusable(true);
        
        JFrame.setDefaultLookAndFeelDecorated(true);
        JFrame frame = new JFrame("Move with KeyListener");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(content);
        frame.setSize(600, 600);
        frame.setLocationByPlatform(true);
        frame.setVisible(true);
        //TODO code application logic here
    }
    
    static class colorIcon implements Icon{
        private Color color;
        private int width;
        private int hight;
        
        JButton button = new JButton();

        public colorIcon(Color color, int width, int hight){
            this.color = color;
            this.width = width;
            this.hight = hight;
        }
        
        public int getIconWidth(){
            return width;
        }
        public int getIconHeight(){
            return hight;
        }
        public void paintIcon(Component c, Graphics g, int x, int y){
            g.setColor(color);
            g.fillRect(x, y, width, hight);
        }
    }
}

