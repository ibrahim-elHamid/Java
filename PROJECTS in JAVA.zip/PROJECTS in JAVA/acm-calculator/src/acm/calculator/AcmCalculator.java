/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package acm.calculator;

import java.util.Scanner;

/**
 *
 * @author Mohammed Eid
 */
public class AcmCalculator {

    public static void calculator() {

        int num1, num2;
        Scanner input = new Scanner(System.in);
        System.out.println("please enter the first number: ");
        num1 = input.nextInt();
        System.out.println("enter number in range from: 0" + " to: " + Math.pow(10, num1));
        num2 = input.nextInt();
        String str = "";
        str += num2;
        int size = str.length();
            int n1 = 1;
            for (int i = 0; i < num1; i++) {
                n1 = n1 * 10;
            }
            System.out.println("n1= " + (n1 - 1));
        /* else if (size < num1) {
            int n = num1;
            while (size < num1) {
                System.out.println();
                n = num1;
                num1 = num1 * num1;
                str = "";
                str += num1;
                size = str.length();

            }
            int s = 1;
            for (int i = 0; i < n; i++) {
                s = s * 10;
            }
            System.out.println("n= " + (s - 1));
        }
        //else if(size < num1){
        //int n1 = num2 * num2;
        str = "";
        str += n1;
        if (str.length() > num1) {
        }
        //}*/ 
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        calculator();
    }
}
