/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package drawpoint;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author Mohammed Eid
 */
public class DrawPoint extends JLabel{
    
    public void paint(Graphics g){
        super.paint(g);
        Graphics2D g2d = (Graphics2D)g;
        g2d.setColor(Color.red);
        g2d.drawLine(100, 100, 105, 100);
        
        
        
        
        /*float[] dash1 = { 2f, 0f, 2f };
        BasicStroke bs1 = new BasicStroke(1, BasicStroke.CAP_BUTT, 
                BasicStroke.CAP_ROUND, 1.0f, dash1, 2f );
        g2d.setStroke(bs1);
        g2d.drawLine(20, 80, 250, 80);
        g2d.draw3DRect(20, 80, 250, 80, true);*/
        /*for(int i=0; i<1000;i++){
            Dimension size = getSize();
            //Insets inset = getInsets();
            
            int w = size.width;
            int h = size.height;
            Random r = new Random();
            int x = Math.abs(r.nextInt()) % w;
            int y = Math.abs(r.nextInt()) % h;
            int a = Math.abs(r.nextInt()) % w;
            int b = Math.abs(r.nextInt()) % h;
            g2d.drawLine(x, y, a, b);
        }*/
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        DrawPoint points = new DrawPoint();
        JFrame frame = new JFrame("Points");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(points);
        frame.setSize(250, 200);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        // TODO code application logic here
    }
}
