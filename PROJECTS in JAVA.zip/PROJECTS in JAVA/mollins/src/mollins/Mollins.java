/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mollins;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author Mohammed Eid
 */
class mollins {
    JFrame f;
JFrame f5;
JLabel l1;
JLabel l2;
JLabel l3;
JLabel l4;
JButton b1;
JButton b2;
JButton b9;
JTextField t11,t12,t13,t14;
JFrame f1;
 JFrame f2;
public int tru;
public int number;
private Double balance=0.0;  
public String tru2="";  
/////////////////////////////////f2
JButton b4;
JButton b5;
JButton b6;
JButton b7;
JButton b8;
JTextField t3;
JTextField t1;
///////////////////////////////el 2gaba
JFrame f3;
 JButton b10;
 ///////////////////////////////////
public static void main(String[]args)
{
mollins m=new mollins();
m.newaction();
}
void newaction()
{
 f=new JFrame("Ahmed akl                         من سيربح المليون");
 f.setBounds(50,50,400,400);
 f.setVisible(true);
 
 f.setLayout(null);
  f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  ////////////////////////////////////////
  l1=new JLabel(new ImageIcon("k1.jpg"));
  l1.setBounds(0,0,400,300);
  f.add(l1);
  
  ///////////////////////////////////////
  b1=new JButton("شروط المسابقه");
  b1.setBounds(30,300,100,50);
  f.add(b1);
  b2=new JButton("الدخول للمسابقه");
  b2.setBounds(270,300,100,50);
  f.add(b2);
  b1.addActionListener((ActionListener) this);
  b2.addActionListener((ActionListener) this);
} 
public void actionPerformed(ActionEvent e)
{
 
if(e.getSource()==b1)
{
f.setVisible(false);
f1=new JFrame("Ahmed akl                                          شروط المسابقه");
  f1.setBounds(40,40,550,550);
 f1.setVisible(true);
 f1.setLayout(null);
 ///////////////////////////////////////////
JLabel l5=new JLabel("WELCOME IN PROGRAM  ***");
  l5.setBounds(20,20,300,40);
  f1.add(l5);
 JLabel l6=new JLabel(" ***MAN SAYARB7 EL MOLLION");
  l6.setBounds(250,20,300,40);
  f1.add(l6);
 
 JLabel l7=new JLabel("* Here, there are 10 Q");
  l7.setBounds(20,150,300,40);
  f1.add(l7);
 JLabel l8=new JLabel("* Each question = 100,000");
  l8.setBounds(20,210,300,40);
  f1.add(l8);
  JLabel l9=new JLabel("* If the answer is correct will earn 100,000");
  l9.setBounds(20,270,300,40);
  f1.add(l9);
 JLabel l10=new JLabel("* If you answered wrong will lose 100,000");
  l10.setBounds(20,330,300,40);
  f1.add(l10);
 JLabel l11=new JLabel("* If your balance equal zero: The game is over");
  l11.setBounds(20,390,300,40);
  f1.add(l11);
  //////////////////////////
  b9=new JButton("OK");
  b9.setBounds(200,450,100,40);
  f1.add(b9);
  b9.addActionListener((ActionListener) this);
  //////////////////////
}
////////////////////////////////////////
 if(e.getSource()==b9 )
{
 f1.setVisible(false);
 f.setVisible(true);
} 
//////////////////////////////////////
if(e.getSource()==b10)
{

f3.setVisible(false);
 number++;

 if(number>10)
 {
 f2.setVisible(false);
  f5=new JFrame("MbC                مركز تلفزيون الشرق الاوسط          اجواء");
 f5.setBounds(100,200,420,250);
 f5.setVisible(true);
 f5.setLayout(null);
  f5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  ////////////////////////////////////////
  JLabel l20=new JLabel("لامر  -----------------------");
  l20.setBounds(270,40,200,50);
  f5.add(l20);
   JLabel l21=new JLabel("مبلغ         " +balance+"   الف جنيه");
  l21.setBounds(270,60,200,50);
  f5.add(l21);
  JLabel l22=new JLabel("تاريخ   1423");
  l22.setBounds(40,20,200,50);
  f5.add(l22);
  
 JTextField t33=new JTextField();
 t33.setBounds(40,60,80,30);
 f5.add(t33);
 t33.setEditable(false);
 t33.setText(balance.toString()+"00");
 
  JLabel l23=new JLabel("Ahmed akl");
  l23.setBounds(40,150,200,50);
  f5.add(l23);
  JLabel l24=new JLabel("---------------------------------------------------------------------------------------------");
  l24.setBounds(0,180,400,20);
  f5.add(l24);
  JLabel l25=new JLabel("255745886214463325586145");
  l25.setBounds(200,185,200,50);
  f5.add(l25);
 }
 else
 {
 quest();
 }
}
 /////////////////////////////////////////////////////////////////////
if(e.getSource()==b2 )
{
f.setVisible(false);
 f2=new JFrame("Ahmed akl                                 المسااااااااااااااااابقه  ");
   f2.setBounds(40,40,500,500);
   f2.setVisible(true);
   f2.setLayout(null);
// f2.setDafoultClosedOperation(JFrame.EXIT_ON_CLOSE);
 /////////////////////////////////
 JLabel l29=new JLabel("balance");
 l29.setBounds(50,20,100,50);
 f2.add(l29);
 ///////////////////////////////
 t1=new JTextField();
 t1.setBounds(170,30,100,30);
 f2.add(t1);
 t1.setText(balance.toString()+"00");
 t1.setEditable(false);
 /////////////////////////////////
 t3=new JTextField();
 t3.setBounds(80,120,300,50);
 f2.add(t3);
 t3.setEditable(false);
 /////////////////////////////////////
 b4=new JButton("OK");
 b4.setBounds(30,250,80,50);
 f2.add(b4);
  t11=new JTextField();
 t11.setBounds(130,250,100,50);
 f2.add(t11);
 t11.setEditable(false);
 //////////////////////////////////////
 b5=new JButton("OK");
 b5.setBounds(340,250,80,50);
 f2.add(b5);
  t12=new JTextField();
 t12.setBounds(250,250,100,50);
 f2.add(t12);
 t12.setEditable(false);
 /////////////////////////////////////
 b6=new JButton("OK");
 b6.setBounds(30,320,80,50);
 f2.add(b6);
  t13=new JTextField();
 t13.setBounds(130,320,100,50);
 f2.add(t13);
 t13.setEditable(false);
 /////////////////////////////
 b7=new JButton("OK");
 b7.setBounds(340,320,80,50);
 f2.add(b7);
  t14=new JTextField();
 t14.setBounds(250,320,100,50);
 f2.add(t14);
 t14.setEditable(false);
 ////////////////////////////////////////
  b8=new JButton("Exit");
 b8.setBounds(200,390,100,50);
 f2.add(b8);
b4.addActionListener((ActionListener) this);
b5.addActionListener((ActionListener) this);
b6.addActionListener((ActionListener) this);
b7.addActionListener((ActionListener) this); 
b8.addActionListener((ActionListener) this); 
///////////////////////////////////////
number=1;
quest();
                                                      
}
 
if(e.getSource()==b8 )
{
try{
 
 f2.setVisible(false);
  f.setVisible(true);
 balance=0.0;  
 number=1;
 }
 catch(Exception e22)
 { 
  System.out.println("out");
 }

}
///////////////////////////el 2gaba
f3=new JFrame("الاجابه");
 f3.setBounds(200,200,300,150);
 //f3.setVisible(true);
 f3.setLayout(null);
 ////////////////////////////////////////
  b10=new JButton("OK");
 b10.setBounds(80,90,80,30);
 f3.add(b10);
 b10.addActionListener((ActionListener) this);
//////////////////////////////
if(tru==1)
 {
if( e.getSource()==b4)
{
 f3.setVisible(true);
 JLabel t=new JLabel("الاجابه صح");
 t.setBounds(40,20,250,50);
 f3.add(t);
 balance+=100;
 if(balance==0.0)
{
f3.setVisible(false);
 //f5.setVisible(true);
} 
 t1.setText(balance.toString()+"00");
  
}
if(e.getSource()==b5)
{
 f3.setVisible(true);
 JLabel t=new JLabel("الاجابه خطأ   ***  الاجابه الصح هى "+tru2);
 t.setBounds(40,20,250,50);                           
 f3.add(t);
 if(balance>0.0)
 {
 balance-=100;
 }
  if(balance<=0.0)
  {
 balance=0.0;
 }
  
    t1.setText(balance.toString()+"00");
	
   
}
if(e.getSource()==b6)
{
f3.setVisible(true);
 JLabel t=new JLabel("الاجابه خطأ   ***  الاجابه الصح هى "+tru2);
 t.setBounds(40,20,250,50);                           
 f3.add(t);
if(balance>0.0)
 {
 balance-=100;
 }
  if(balance<=0.0)
  {
 balance=0.0;;  
 } t1.setText(balance.toString()+"00");
  
}
 if(e.getSource()==b7)
{
f3.setVisible(true);
 JLabel t=new JLabel("الاجابه خطأ   ***  الاجابه الصح هى "+tru2);
 t.setBounds(40,20,250,50);                           
 f3.add(t);
if(balance>0.0)
 {
 balance-=100;
 }
  if(balance<=0.0)
  {
 balance=0.0;;  
 } t1.setText(balance.toString()+"00");
   
}  
}
/////////////////////////////////////////
   if(tru==2)
   {
   if(e.getSource()==b5)
{
f3.setVisible(true);
 JLabel t=new JLabel("الاجابه صح");
 t.setBounds(40,20,250,50);
 f3.add(t);
 balance+=100;
 t1.setText(balance.toString()+"00");
  
}
if(e.getSource()==b4)
{
f3.setVisible(true);
 JLabel t=new JLabel("الاجابه خطأ   ***  الاجابه الصح هى "+tru2);
 t.setBounds(40,20,250,50);                           
 f3.add(t);
 if(balance>0.0)
 {
 balance-=100;
 }
  if(balance<=0.0)
  {
 balance=0.0;;  
 }
 t1.setText(balance.toString()+"00");
 
}
if(e.getSource()==b6)
{
f3.setVisible(true);
 JLabel t=new JLabel("الاجابه خطأ   ***  الاجابه الصح هى "+tru2);
 t.setBounds(40,20,250,50);                           
 f3.add(t);
 if(balance>0.0)
 {
 balance-=100;
 }
  if(balance<=0.0)
  {
 balance=0.0;;  
 } t1.setText(balance.toString()+"00");
   
}
 if(e.getSource()==b7)
{
f3.setVisible(true);
 JLabel t=new JLabel("الاجابه خطأ   ***  الاجابه الصح هى "+tru2);
 t.setBounds(40,20,250,50);                           
 f3.add(t);
 if(balance>0.0)
 {
 balance-=100;
 }
  if(balance<=0.0)
  {
 balance=0.0;;  
 }
 t1.setText(balance.toString()+"00");
  
}
} 
////////////////////////////////////////////
if(tru==3)
{
 if(e.getSource()==b6)
{
f3.setVisible(true);
 JLabel t=new JLabel("الاجابه صح");
 t.setBounds(40,20,250,50);
 f3.add(t);

 balance+=100;
 t1.setText(balance.toString()+"00");
   
}
if(e.getSource()==b5)
{
f3.setVisible(true);
 JLabel t=new JLabel("الاجابه خطأ   ***  الاجابه الصح هى "+tru2);
 t.setBounds(40,20,250,50);                           
 f3.add(t);
 if(balance>0.0)
 {
 balance-=100;
 }
  if(balance<=0.0)
  {
 balance=0.0;;  
 }
 t1.setText(balance.toString()+"00");
  
}
if(e.getSource()==b4)
{
f3.setVisible(true);
 JLabel t=new JLabel("الاجابه خطأ   ***  الاجابه الصح هى "+tru2);
 t.setBounds(40,20,250,50);                           
 f3.add(t);
if(balance>0.0)
 {
 balance-=100;
 }
  if(balance<=0.0)
  {
 balance=0.0;;  
 } t1.setText(balance.toString()+"00");
  
}
 if(e.getSource()==b7)
{
f3.setVisible(true);
 JLabel t=new JLabel("الاجابه خطأ   ***  الاجابه الصح هى "+tru2);
 t.setBounds(40,20,250,50);                           
 f3.add(t);
if(balance>0.0)
 {
 balance-=100;
 }
  if(balance<=0.0)
  {
 balance=0.0;;  
 }
 t1.setText(balance.toString()+"00");
  
}  

}
/////////////////////////////////////////
if(tru==4)
{
if(e.getSource()==b7)
{
f3.setVisible(true);
 JLabel t=new JLabel("الاجابه صح");
 t.setBounds(40,20,250,50);
 f3.add(t);

 balance+=100;
 t1.setText(balance.toString()+"00");
   
}
 if(e.getSource()==b5)
{
f3.setVisible(true);
 JLabel t=new JLabel("الاجابه خطأ   ***  الاجابه الصح هى "+tru2);
 t.setBounds(40,20,250,50);                           
 f3.add(t);
if(balance>0.0)
 {
 balance-=100;
 }
  if(balance<=0.0)
  {
 balance=0.0;;  
 }
 t1.setText(balance.toString()+"00");
  
}
if(e.getSource()==b6)
{
f3.setVisible(true);
 JLabel t=new JLabel("الاجابه خطأ   ***  الاجابه الصح هى "+tru2);
 t.setBounds(40,20,250,50);                           
 f3.add(t);
if(balance>0.0)
 {
 balance-=100;
 }
  if(balance<=0.0)
  {
 balance=0.0;;  
 }
 t1.setText(balance.toString()+"00");
 
}
 if(e.getSource()==b4)
{
f3.setVisible(true);
 JLabel t=new JLabel("الاجابه خطأ   ***  الاجابه الصح هى "+tru2);
 t.setBounds(40,20,250,50);                           
 f3.add(t);
if(balance>0.0)
 {
 balance-=100; }
  if(balance<=0.0)
  {
 
 balance=0.0;;  
 
 }
 t1.setText(balance.toString()+"00");
  
} 
} 
   
}
 ///////////////////////////////////////////
void quest()
{
 
 
 
 if(number==1)
 {
     t3.setText("ما هو الدب الاكبر والدب الاصغر :");
	 t11.setText("حيوانا قطبيان");
	 t12.setText("مجموعتان نحميه");
	 t13.setText("حيوان روسيان");
	 t14.setText("بحيرتان افريقيتان");
	 tru=2;
	 tru2="مجموعتان نجميه";
}    
else if(number==2)
{
	 t3.setText("بالاشاره يفهم ...........");
	 t11.setText("الرئيس");
	 t12.setText("الزكى");
	 t13.setText("اللبيب");
	 t14.setText("الخبير");
	 tru=3;
	 tru2="اللبيب";
 }   
 else if(number==3)
{
	 t3.setText("اداه من عده شغل الحائك,فما هى  ؟");
	 t11.setText("السماعه");
	 t12.setText("المطرقه");
	 t13.setText("الجرفه");
	 t14.setText("المقص");
	 tru=4;
	 tru2="المقص";
 }   
 else if(number==4)
{
	 t3.setText("ثقل مسلوب   *   للغواص مطلوب    *    لابسه مغصوب   *    للقوع مسحوب");
	 t11.setText("الحجر");
	 t12.setText("المفلقه");
	 t13.setText("الجرخ");
	 t14.setText("الفطام");
	 tru=1;
    tru2="الحجر";	 
 }  
 else if(number==5)
{
	 t3.setText("اين يوجد قبر صلاح الدين الايوبى  ؟");
	 t11.setText("القاهره");
	 t12.setText("دمشق");
	 t13.setText("القدس");
	 t14.setText("المدينه");
	 tru=2;
	 tru2="دمشق";
	 
  
 }
 else if(number==6)
 {
     t3.setText("فى عهد من من الانبياء بنى المسجد الاقصى   ؟");
	 t11.setText("ابراهيم_ع");
	 t12.setText("الياس _ع");
	 t13.setText("سليمان_ع");
	 t14.setText("موسى_ع");
	 tru=3;
	 tru2="سليمان_ع";
}    
else if(number==7)
{
	 t3.setText("ما الطائر الذى يعتبره العرب نزير للشؤم  ؟");
	 t11.setText("الحمام");
	 t12.setText("البوم");
	 t13.setText("الكنارى");
	 t14.setText("الببغاء");
	 tru=2;
	 tru2="البوم";
 }   
 else if(number==8)
{
	 t3.setText("أكل الدهر عليه وشرب هى جمله تصف شيئا  ......؟");
	 t11.setText("حديثا");
	 t12.setText("معاصرا");
	 t13.setText("جديدا");
	 t14.setText("قديما");
	 tru=4;
	 tru2="قديما";
 }   
 else if(number==9)
{
	 t3.setText("ما عاصمه المملكه العربيه السعوديه؟");
	 t11.setText("الخبر");
	 t12.setText("الرياض");
	 t13.setText("جده");
	 t14.setText("ابما");
	 tru=2;
    tru2="الرياض";	 
 }  
 else if(number==10)
{
	 t3.setText("ما اسم عاصه مؤسس الدوله العباسه  ابوالعباس السفاح  ؟");
	 t11.setText("بغداد");
	 t12.setText("البصره");
	 t13.setText("الانبار");
	 t14.setText("الكوفه");
	 tru=3;
	 tru2="الانبار";
	 
  
 }
 }

    /**
     * @param args the command line arguments
     */
    //public static void main(String[] args) {
        // TODO code application logic here
    //}
}
