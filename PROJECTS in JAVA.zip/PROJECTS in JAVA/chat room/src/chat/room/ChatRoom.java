/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.room;

import java.util.Scanner;

/**
 *
 * @author Mohammed Eid
 */
public class ChatRoom {
    
    public static void checkWrod(){
    String word = "";
    System.out.println("enter the word to send: ");
    Scanner input = new Scanner(System.in);
    word = input.next();
    String s = "hello";
    int count = 0;
    for(int i=0;i<word.length();i++){
        char ch = word.charAt(i);
        if(s.charAt(count) == ch){
    for(int j=i+1;j<word.length()-i;j++){
    char c = word.charAt(j);
    if(c == s.charAt(count)){
    
    }
    else if(c == s.charAt(count+1)){
    ++count;
    }
    else {break;}
    }
    }
    }
    if(word.contains("hello")){
    System.out.println("YES!");
    }
    else{
    System.out.println("NO!");
    }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        checkWrod();
        // TODO code application logic here
    }
}
