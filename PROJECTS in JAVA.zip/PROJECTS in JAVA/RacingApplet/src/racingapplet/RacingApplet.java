/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package racingapplet;

import javax.swing.JApplet;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.applet.*;
import javax.swing.*;
/**
 *
 * @author Mohammed Eid
 */
public class RacingApplet extends JApplet{
    
    private JLabel Car1JLabel, Car2JLabel, Car3JLabel, Car4JLabel;

    private JTextField Car1JTextField, Car2JTextField, Car3JTextField, Car4JTextField;

    private JButton StartJButton, StopJButton;
    private Image MarioImage, LuigiImage, YoshiImage, BowserImage;

    private Timer timer;

    private Image dbImage;

    private Graphics dbg;

    private int Car1;

    private int Car2;

    private int Car3;

    private int Car4;

    private int MarioX = 4, LuigiX = 4, YoshiX = 4, BowserX = 4;

 

    public void init(){
 

        Container background = getContentPane();

        background.setBackground(Color.white);

        setLayout(new FlowLayout());

 

        StartJButton = new JButton("Start");

        add(StartJButton);

 

        Car1JLabel = new JLabel("Car 1: ");

        add(Car1JLabel);

        Car1JTextField = new JTextField("", 3);

        add(Car1JTextField);

        Car2JLabel = new JLabel("Car 2: ");

        add(Car2JLabel);

        Car2JTextField = new JTextField("", 3);

        add(Car2JTextField);

        Car3JLabel = new JLabel("Car 3: ");

        add(Car3JLabel);

        Car3JTextField = new JTextField("", 3);

        add(Car3JTextField);

        Car4JLabel = new JLabel("Car 4: ");

        add(Car4JLabel);

        Car4JTextField = new JTextField("", 3);

        add(Car4JTextField);

 

        StopJButton = new JButton("Stop");

        add(StopJButton);

        ImageIcon sid = new ImageIcon(RacingApplet.class.getResource("1.gif"));
        MarioImage = sid.getImage();
        ImageIcon sid2 = new ImageIcon(RacingApplet.class.getResource("2.gif"));
        LuigiImage = sid2.getImage();
        ImageIcon sid1 = new ImageIcon(RacingApplet.class.getResource("3.gif"));
        YoshiImage = sid1.getImage();
        ImageIcon sid3 = new ImageIcon(RacingApplet.class.getResource("4.gif"));
        BowserImage = sid3.getImage();
        //MarioImage = getImage(getDocumentBase(), "1.gif");

        //LuigiImage = getImage(getDocumentBase(), "2.gif");

        //YoshiImage = getImage(getDocumentBase(), "3.gif");

        //BowserImage = getImage(getDocumentBase(), "4.gif");

        timer = new Timer(50, new TimerHandler());
        JOptionPane.showMessageDialog(null, "To make the cars move please enter a\n" +

                        "number between 1 and 5 in each text box.\n " + "\n"+

                        "1 = Slowest Speed   5 = Fastest Speed\n " + "\n" +

                        "                   IMPORTANT NOTE* \n\n" +

                        "*If you enter a number lower than 1,\n" +

                        "your number will automatically become 1.\n " + "\n" +

                        "*If you enter a number higher than 5,\n" +

                        "your number will automatically become 5. ");
    }
    public void start(){

        StartJButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {

 

                Car1 = Integer.parseInt(Car1JTextField.getText());

                Car2 = Integer.parseInt(Car2JTextField.getText());

                Car3 = Integer.parseInt(Car3JTextField.getText());

                Car4 = Integer.parseInt(Car4JTextField.getText());

                if (Car1 > 5)
                {
                    Car1 = 5;

                }

                else if (Car1 < 1)
                    Car1 = 1;
 

                if (Car2 > 5)

                {

                    Car2 = 5;
                }

                else if (Car2 < 1)

                    Car2 = 1;
          if (Car3 > 5)
                {

                    Car3 = 5;

                }

                else if (Car3 < 1)

                    Car3 = 1;

                if (Car4 > 5)
                {
                    Car4 = 5;

                }
                else if (Car4 < 1)

                    Car4 = 1;

 

                if(timer == null)

                                {

                    timer.start();
                                }
                else

                {

                    if (!timer.isRunning())

                        timer.restart();
                }}});
        StopJButton.addActionListener(new ActionListener()

        {

            public void actionPerformed(ActionEvent event)

            {

 

                timer.stop();

            }

        }

    );
}
    private class TimerHandler implements ActionListener{

 

        public void actionPerformed(ActionEvent actionEvent){

            repaint();

                        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        RacingApplet r = new RacingApplet();
        r.init();
        System.out.println("abo alaa");
        // TODO code application logic here
    }
}
